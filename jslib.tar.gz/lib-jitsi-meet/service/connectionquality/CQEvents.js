var CQEvents = {
    LOCALSTATS_UPDATED: "cq.localstats_updated",
    REMOTESTATS_UPDATED: "cq.remotestats_updated",
    STOP: "cq.stop"
};

module.exports = CQEvents;