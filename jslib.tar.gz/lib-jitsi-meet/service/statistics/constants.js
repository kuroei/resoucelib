var Constants = {
    LOCAL_JID: 'local'
};
module.exports = Constants;